// pages/dateint/dateint.js
Page({
  _dataJianru: function (e) {
    console.log(e)
    //动态修改数据源
    //this.data.变量名.push("变量")，实现对变量数组的变量内容增加，但注意不会触发页面重新渲染。需要以下调用。
    //this.seData({
    //  变量名: this.data.变量名
    //})  用于触发页面重新渲染，将数组中的新元素渲染到页面



  },
  _dataDel: function () {
    console.log("删除")

  },
  _biaolistChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index:e.detail.value,
    })
    // this.data.index = e.detail.value
    console.log(this.data.index,'11111')
    // switch (e.detail.value) {
    //   case 0:
    //     i=0;
    //     break;
    //   case 1:
    //     i=1;
    //   default:
    //     break;
    // }
  },
  _hangKeyInput: function (e) {
    this.setData({
      inputVhang: e.detail.value
    })
  },
  _lnameKeyInput: function (e) {
    this.setData({
      inputVlname: e.detail.value
    })
  },
  /**
   * 页面的初始数据
   */
  data: {
    biaolist: ['电影数据', '电视剧数据', '艺人数据', '动画数据','动漫人物数据','游戏数据','游戏人物','小说数据','小说人物','番号','里番','漫画'],
    leixing: ['未知','动作','奇幻','喜剧','恐怖','冒险','爱情','警匪','科幻','战争','灾难','史诗','实验','微电影','悬疑','音乐','黑帮','纪录','公路','意识流','动画','惊悚','西部','飞车','家庭','超级英雄'],
    yxleixing: ['未知','RPG游戏','AVG游戏','ACT游戏','策略','经营','射击','益智','体育竞技','竞速','卡牌','音游','网游','养成','模拟','格斗','解密','恐怖','Rlike游戏','对抗','自由建造'],
    station: ['PC平台','NS平台','PSP平台','手游'],
    xiaoshuo: ['未知','武侠','玄幻','仙侠','科幻','都市青春','穿越历史','军事幻想','游戏世界','重生','体育','变身','宅文','同人','综漫','H文'],
    guobie: ['英国 England','美国 America','加拿大Canada','俄罗斯 Russia','大陆 China','希腊 Greece','法国 France','德国 Germany','日本 Japan','韩国 Korea','香港 HongKong','台湾 TaiWan','泰国 Thailand','印度 India'],
    signs: ['白羊座','金牛座','双子座','巨蟹座','狮子座','处女座','天枰座','天蝎座','射手座','魔蝎座','水瓶座','双鱼座'],
    score: ['1分','2分','3分','4分','5分'],
    date: '2016-09-01',
    index: 0,
    inputValue: '',
    keyId:'',
    chooseInputlist: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
//app.js
App({
  onLaunch: function () {  //app生命周期方法
    //初始化操作
    wx.cloud.init({
      env:'misaka10013-80b8a',  //云环境id
      traceUser:true  //追踪使用用户
    })
    
  },
  globalData: {
    userInfo: null
  }
})
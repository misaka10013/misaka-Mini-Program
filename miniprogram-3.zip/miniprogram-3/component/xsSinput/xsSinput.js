// component/dySinput/dySinput.js
var util = require('../../utils/util.js');
const db=wx.cloud.database()

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    score:Object,
  },

  /**
   * 组件的初始数据
   */
  data: {
    inputItems:[],
    findItems:[],
    delItems:[],
    xiaoshuo: ['未知','武侠','玄幻','仙侠','科幻','都市青春','穿越历史','军事幻想','游戏世界','重生','体育','变身','宅文','同人','综漫','H文'],
    wanjie: ['已完结','连载中','烂尾'],
    idLx:0,
    idISW:0,
    idPfM:0,
    idPfE:0,
    keyId:0,
    date: '2016-09-01'
  },

  ready: function() {
    db.collection('systm').doc('d232df4c5f9e82f90005425c26ccb296')
    .get({
      success: res => {
        // res.data 包含该记录的数据
        // console.log(res.data.dy)
        this.setData({
          inputItems:res.data.xs,  //传值给data页面数组，实现页面
         })
      }
    })
  },
  /**
   * 组件的方法列表
   */
  methods: {
    _DateChangeLx: function(e) {
      // console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        idLx:e.detail.value,
      })
    },
    _DateChangeISW: function(e) {
      // console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        idISW:e.detail.value,
      })
    },
    _DateChangePfM: function(e) {
      // console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        idPfM:e.detail.value,
      })
    },
    _DateChangePfE: function(e) {
      // console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        idPfE:e.detail.value,
      })
    },
    _DateChangeTm: function(e) {
      // console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        date: e.detail.value
      })
    },
    _findInput:function(e){
      const _ = db.command
      if (e.detail.value!= ''){
        console.log('正在搜索：',e.detail.value)
        db.collection("xsSinput").where(_.or([
          {
            moName: db.RegExp({
              regexp: '.*' + e.detail.value,
              options: 'i',
            })
          },
          {
            acTor: db.RegExp({
              regexp: '.*' + e.detail.value,
              options: 'i',
          })
          }
          // {
          //   keyId: db.RegExp({
          //     regexp: '.*' + e.detail.value,
          //     options: 'i',
          //   })
          // }
        ]) //模糊搜索
        ).limit(3).field({
          moName:true,
          // keyId:true,
          MscOre:true,
          author:true
          // _id:false
        }).orderBy('MscOre','desc').get()
        .then(res=>{
          this.setData({
            findItems:res.data
          })
          console.log(this.data.findItems)
        })
      }else
      {
        this.setData({
          findItems:''
        })
        console.log('停止搜索',e.detail.value)

    }
    },
    _delData:function(e){
      console.log('需要删除的id',e.detail.value.key)
      db.collection("xsSinput").doc(e.detail.value.key).remove()
       .then(res=>{
         console.log("成功删除数据",e.detail.value.key)
         wx.showToast({
          title: '删除成功！',
          icon:'success'
        })
       })
      // console.log(this.methods)
      // this.methods._findInput()
    },
    _dataJianru: function (e) {
      console.log(e)  //获取到表中的值，需上传电影表
      const accountCollection = db.collection("xsSinput")
      accountCollection.add({
        data:{
          moName:e.detail.value.名称,
          author:e.detail.value.作者,
          coNtent:e.detail.value.内容,
          tyPe:e.detail.value.类型,
          isComp:e.detail.value.是否完结,
          MscOre:e.detail.value.综合评分,
          sexScOre:e.detail.value.色气评分,
          review:e.detail.value.评价,
          reMark:e.detail.value.备注,
          // keyId:e.detail.value.keyId
        }

      }).then(res=>{
        wx.showToast({
          title: '上传成功',
          icon:'success'
        })
      })

    },
  }
})

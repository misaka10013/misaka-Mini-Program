// component/dySinput/dySinput.js
var util = require('../../utils/util.js');
const db=wx.cloud.database()

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    score:Object,
    guobie:Object
  },

  /**
   * 组件的初始数据
   */
  data: {
    inputItems:[],
    findItems:[],
    delItems:[],
    isMosaic:["未知","有马赛克","无码"],
    isSubtitle:["未知","有字幕","无字幕","无字幕中文"],
    idMSK:0,
    idZM:0,
    idPfP:0,
    idPfS:0,
    idPfM:0,
    idPfE:0,
    keyId:0,
    date: '2016-09-01'
  },

  ready: function() {
    db.collection('systm').doc('d232df4c5f9e82f90005425f05e1a30c')
    .get({
      success: res => {
        // res.data 包含该记录的数据
        // console.log(res.data.dy)
        this.setData({
          inputItems:res.data.lfdm,  //传值给data页面数组，实现页面
         })
      }
    })
  },
  /**
   * 组件的方法列表
   */
  methods: {
    _DateChangeMSK: function(e) {
      // console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        idMSK:e.detail.value,
      })
    },
    _DateChangeZM: function(e) {
      // console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        idZM:e.detail.value,
      })
    },
    _DateChangePfP: function(e) {
      // console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        idPfP:e.detail.value,
      })
    },
    _DateChangePfS: function(e) {
      // console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        idPfS:e.detail.value,
      })
    },
    _DateChangePfM: function(e) {
      // console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        idPfM:e.detail.value,
      })
    },
    _DateChangePfE: function(e) {
      // console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        idPfE:e.detail.value,
      })
    },
    _DateChangeTm: function(e) {
      // console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        date: e.detail.value
      })
    },
    _findInput:function(e){
      const _ = db.command
      if (e.detail.value!= ''){
        console.log('正在搜索：',e.detail.value)
        db.collection("lfdmSinput").where(_.or([
          {
            moName: db.RegExp({
              regexp: '.*' + e.detail.value,
              options: 'i',
            })
          },
          {
            acTor: db.RegExp({
              regexp: '.*' + e.detail.value,
              options: 'i',
          })
          }
          // {
          //   keyId: db.RegExp({
          //     regexp: '.*' + e.detail.value,
          //     options: 'i',
          //   })
          // }
        ]) //模糊搜索
        ).limit(3).field({
          moName:true,
          MscOre:true,
          acTor:true
          // _id:false
        }).orderBy('MscOre','desc').get()
        .then(res=>{
          this.setData({
            findItems:res.data
          })
          console.log(this.data.findItems)
        })
      }else
      {
        this.setData({
          findItems:''
        })
        console.log('停止搜索',e.detail.value)

    }
    },
    _delData:function(e){
      console.log('需要删除的id',e.detail.value.key)
      db.collection("moive").doc(e.detail.value.key).remove()
       .then(res=>{
         console.log("成功删除数据",e.detail.value.key)
         wx.showToast({
          title: '删除成功！',
          icon:'success'
        })
       })
      // console.log(this.methods)
      // this.methods._findInput()
    },
    _dataJianru: function (e) {
      console.log(e)  //获取到表中的值，需上传电影表
      const accountCollection = db.collection("lfdmSinput")
      accountCollection.add({
        data:{
          moName:e.detail.value.名称,
          foName:e.detail.value.外译名,
          coNtent:e.detail.value.内容,
          proDucer:e.detail.value.制作人,
          wrIter:e.detail.value.编剧,
          acTor:e.detail.value.重要角色,
          PscOre:e.detail.value.画风评分,
          SscOre:e.detail.value.剧情评分,
          MscOre:e.detail.value.综合评分,
          sexScOre:e.detail.value.色气评分,
          prOdata:e.detail.value.出品时间,
          isMosaic:e.detail.value.马赛克,
          isSubtitle:e.detail.value.字幕,
          coNtent:e.detail.value.内容,
          reMark:e.detail.value.备注,
          tUrl:e.detail.value.图片,
          // keyId:e.detail.value.keyId
        }

      }).then(res=>{
        wx.showToast({
          title: '上传成功',
          icon:'success'
        })
      })

    },
  }
})

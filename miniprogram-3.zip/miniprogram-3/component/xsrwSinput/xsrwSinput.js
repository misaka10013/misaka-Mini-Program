// component/dySinput/dySinput.js
var util = require('../../utils/util.js');
const db=wx.cloud.database()

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    score:Object,
  },

  /**
   * 组件的初始数据
   */
  data: {
    inputItems:[],
    findItems:[],
    delItems:[],
    idLx:0,
    idDy:0,
    idPf:0,
    keyId:0,
    date: '2016-09-01'
  },

  ready: function() {
    db.collection('systm').doc('d232df4c5f9e82f90005425d3b36c96d')
    .get({
      success: res => {
        // res.data 包含该记录的数据
        // console.log(res.data.dy)
        this.setData({
          inputItems:res.data.xsrw,  //传值给data页面数组，实现页面
         })
      }
    })
  },
  /**
   * 组件的方法列表
   */
  methods: {
    _DateChangePf: function(e) {
      // console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        idPf:e.detail.value,
      })
      // var a=util.formatTime(new Date());
      // a=a.replace(new RegExp('/','g'),'');
      // a=a.replace(new RegExp(' ','g'),'');
      // a=a.replace(new RegExp(':','g'),'');
      // this.setData({
      //   keyId: a
      // })
      // console.log(a)  //
    },
    _DateChangeTm: function(e) {
      // console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        date: e.detail.value
      })
    },
    _findInput:function(e){
      const _ = db.command
      if (e.detail.value!= ''){
        console.log('正在搜索：',e.detail.value)
        db.collection("xsrwSinput").where(_.or([
          {
            moName: db.RegExp({
              regexp: '.*' + e.detail.value,
              options: 'i',
            })
          },
          {
            acTor: db.RegExp({
              regexp: '.*' + e.detail.value,
              options: 'i',
          })
          }
          // {
          //   keyId: db.RegExp({
          //     regexp: '.*' + e.detail.value,
          //     options: 'i',
          //   })
          // }
        ]) //模糊搜索
        ).limit(3).field({
          moName:true,
          // keyId:true,
          scOre:true,
          frStory:true
          // _id:false
        }).orderBy('scOre','desc').get()
        .then(res=>{
          this.setData({
            findItems:res.data
          })
          console.log(this.data.findItems)
        })
      }else
      {
        this.setData({
          findItems:''
        })
        console.log('停止搜索',e.detail.value)

    }
    },
    _delData:function(e){
      console.log('需要删除的id',e.detail.value.key)
      db.collection("moive").doc(e.detail.value.key).remove()
       .then(res=>{
         console.log("成功删除数据",e.detail.value.key)
         wx.showToast({
          title: '删除成功！',
          icon:'success'
        })
       })
      // console.log(this.methods)
      // this.methods._findInput()
    },
    _dataJianru: function (e) {
      console.log(e)  //获取到表中的值，需上传电影表
      const accountCollection = db.collection("xsrwSinput")
      accountCollection.add({
        data:{
          moName:e.detail.value.人物,
          frStory:e.detail.value.小说,
          scOre:e.detail.value.评分,
          group:e.detail.value.组织阵营,
          home:e.detail.value.地址,
          keyword:e.detail.value.关键词,
          reMark:e.detail.value.备注,
          // keyId:e.detail.value.keyId
        }

      }).then(res=>{
        wx.showToast({
          title: '上传成功',
          icon:'success'
        })
      })

    },
  }
})
